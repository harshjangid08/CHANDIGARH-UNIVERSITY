module.exports = {
  plugins: [require('prettier-plugin-tailwindcss')],
  singleQuote: true,
};
